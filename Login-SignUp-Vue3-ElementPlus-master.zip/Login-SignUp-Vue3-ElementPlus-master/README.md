## 登录注册页面模板

- Vue3
- Element-Plus
- FontAwesome
- axios

![登录页面](preview/login.png)

![注册页面](preview/signup.png)

<img src="preview/mobile.png" height="400px"></img>

源自 [LoginRadius/awesome-login-pages](https://github.com/LoginRadius/awesome-login-pages) 的 `login-form-v34` 修改而成